import { configureStore, createSlice, type PayloadAction } from '@reduxjs/toolkit';
import type { CanaChangeEvent } from '@jumentix/cana';
import { connectCanaToRedux } from '@jumentix/cana-react/redux';
import { cana, loadAll, seedInitialData, formatEvent, type Category, type Task } from './cana';

type State = { categories: Category[]; tasks: Task[]; events: string[] };

function upsert<T extends { id: string }>(records: T[], record: T) {
  const next = records.filter((item) => item.id !== record.id).concat(record);
  return next;
}

const slice = createSlice({
  name: 'tasks',
  initialState: { categories: [], tasks: [], events: [] } as State,
  reducers: {
    replaceAll(_state, action: PayloadAction<{ categories: Category[]; tasks: Task[] }>) {
      return { categories: action.payload.categories, tasks: action.payload.tasks, events: [] };
    },
    applyCanaEvent(state, action: PayloadAction<CanaChangeEvent>) {
      const event = action.payload;
      state.events = [...state.events, formatEvent(event)].slice(-8);
      if (event.store === 'categories' && event.record) {
        state.categories = upsert(state.categories, event.record as Category)
          .sort((a, b) => a.name.localeCompare(b.name));
      }
      if (event.store === 'tasks' && event.record) {
        state.tasks = upsert(state.tasks, event.record as Task)
          .sort((a, b) => a.updatedAt - b.updatedAt);
      }
    }
  }
});

export const { applyCanaEvent, replaceAll } = slice.actions;

export const store = configureStore({ reducer: slice.reducer });
export type RootState = ReturnType<typeof store.getState>;

export async function startCanaRedux() {
  await seedInitialData();
  store.dispatch(replaceAll(await loadAll()));
  const bridge = connectCanaToRedux({
    client: cana,
    dispatch: store.dispatch,
    mapEvent: (event) => applyCanaEvent(event)
  });
  return bridge.stop;
}

export async function addTask(title: string, categoryId: string) {
  const now = Date.now();
  await cana.table<Task>('tasks').add({
    id: crypto.randomUUID(),
    title,
    categoryId,
    completed: false,
    priority: 'medium',
    createdAt: now,
    updatedAt: now
  });
}

export async function toggleTask(task: Task) {
  await cana.table<Task>('tasks').update(task.id, {
    completed: !task.completed,
    updatedAt: Date.now()
  });
}