import { useEffect } from 'react';
import { Provider, useSelector } from 'react-redux';
import { addTask, toggleTask, startCanaRedux, store, type RootState } from './store';

function ReduxTaskBoard() {
  const { categories, tasks, events } = useSelector((state: RootState) => state);

  useEffect(() => {
    let stop = () => {};
    void startCanaRedux().then((cleanup) => { stop = cleanup; });
    return () => stop();
  }, []);

  return (
    <main className="app">
      <h1>Cana + React Redux</h1>
      <div className="toolbar">
        <button onClick={() => void addTask('New Redux task', 'work')}>Add task</button>
      </div>
      <section className="board">
        {categories.map((category) => (
          <article className="category" key={category.id}>
            <h2>{category.name}</h2>
            {tasks.filter((task) => task.categoryId === category.id).map((task) => (
              <button className="task" key={task.id} onClick={() => void toggleTask(task)}>
                {task.completed ? 'Done: ' : ''}{task.title}
              </button>
            ))}
          </article>
        ))}
      </section>
      <pre className="events">{events.join('\n') || 'No events yet.'}</pre>
    </main>
  );
}

export default function App() {
  return (
    <Provider store={store}>
      <ReduxTaskBoard />
    </Provider>
  );
}