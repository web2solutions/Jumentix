import { useEffect } from 'react';
import { Provider, useDispatch, useSelector } from 'react-redux';
import {
  adicionarTarefa,
  alternarTarefa,
  criarCategoriaComPrimeiraTarefa,
  startCanaReduxComReplay,
  store,
  type RootState
} from './store';

function QuadroReduxAvancado() {
  const dispatch = useDispatch<typeof store.dispatch>();
  const { categorias, tarefas, eventos } = useSelector((state: RootState) => state);

  useEffect(() => {
    let stop = () => {};
    void startCanaReduxComReplay().then((cleanup) => { stop = cleanup; });
    return () => stop();
  }, []);

  return (
    <main className="app">
      <h1>Cana + React Redux avancado</h1>
      <div className="toolbar">
        <button onClick={() => void adicionarTarefa('Nova tarefa Redux', 'trabalho')}>Adicionar tarefa</button>
        <button onClick={() => void dispatch(criarCategoriaComPrimeiraTarefa({
          nome: 'Release',
          titulo: 'Criada em uma transacao'
        }))}>
          Criar categoria + tarefa
        </button>
      </div>
      <section className="board">
        {categorias.map((categoria) => (
          <article className="categoria" key={categoria.id}>
            <h2>{categoria.nome}</h2>
            {tarefas.filter((tarefa) => tarefa.categoriaId === categoria.id).map((tarefa) => (
              <button className="tarefa" key={tarefa.id} onClick={() => void alternarTarefa(tarefa)}>
                {tarefa.concluida ? 'Concluida: ' : ''}{tarefa.titulo}
              </button>
            ))}
          </article>
        ))}
      </section>
      <pre className="eventos">{eventos.join('\n') || 'Sem eventos ainda.'}</pre>
    </main>
  );
}

export default function App() {
  return (
    <Provider store={store}>
      <QuadroReduxAvancado />
    </Provider>
  );
}