import { configureStore, createAsyncThunk, createSlice, type PayloadAction } from '@reduxjs/toolkit';
import { isCanaErrorCode, type CanaChangeEvent } from '@jumentix/cana';
import { connectCanaToRedux } from '@jumentix/cana-react/redux';
import { cana, carregarTudo, criarDadosIniciais, textoEvento, type Categoria, type Tarefa } from './cana';

type State = { categorias: Categoria[]; tarefas: Tarefa[]; eventos: string[]; canaError: unknown };
let ultimoCursor = Number(localStorage.getItem('redux:lastCursor') ?? 0);

function upsert<T extends { id: string }>(records: T[], record: T) {
  return records.filter((item) => item.id !== record.id).concat(record);
}

const slice = createSlice({
  name: 'tarefas',
  initialState: { categorias: [], tarefas: [], eventos: [], canaError: null } as State,
  reducers: {
    replaceAll(state, action: PayloadAction<{ categorias: Categoria[]; tarefas: Tarefa[] }>) {
      state.categorias = action.payload.categorias;
      state.tarefas = action.payload.tarefas;
    },
    setCanaError(state, action: PayloadAction<unknown>) {
      state.canaError = action.payload;
    },
    applyCanaEvent(state, action: PayloadAction<CanaChangeEvent>) {
      const event = action.payload;
      ultimoCursor = event.cursor;
      localStorage.setItem('redux:lastCursor', String(ultimoCursor));
      state.eventos = [...state.eventos, textoEvento(event)].slice(-8);
      if (event.store === 'categorias' && event.record) {
        state.categorias = upsert(state.categorias, event.record as Categoria)
          .sort((a, b) => a.nome.localeCompare(b.nome));
      }
      if (event.store === 'tarefas' && event.record) {
        state.tarefas = upsert(state.tarefas, event.record as Tarefa)
          .sort((a, b) => a.atualizadaEm - b.atualizadaEm);
      }
    }
  }
});

export const { applyCanaEvent, replaceAll, setCanaError } = slice.actions;
export const store = configureStore({ reducer: slice.reducer });
export type RootState = ReturnType<typeof store.getState>;

export async function startCanaReduxComReplay() {
  await criarDadosIniciais();
  store.dispatch(replaceAll(await carregarTudo()));
  try {
    const bridge = connectCanaToRedux({
      client: cana,
      dispatch: store.dispatch,
      sinceCursor: ultimoCursor,
      mapEvent: (event) => applyCanaEvent(event)
    });
    return bridge.stop;
  } catch (error) {
    if (isCanaErrorCode(error, 'NotFound')) {
      store.dispatch(replaceAll(await carregarTudo()));
      const bridge = connectCanaToRedux({
        client: cana,
        dispatch: store.dispatch,
        mapEvent: (event) => applyCanaEvent(event)
      });
      return bridge.stop;
    }
    store.dispatch(setCanaError(error));
    throw error;
  }
}

export const criarCategoriaComPrimeiraTarefa = createAsyncThunk(
  'tarefas/criarCategoriaComPrimeiraTarefa',
  async ({ nome, titulo }: { nome: string; titulo: string }) => {
    const agora = Date.now();
    const categoriaId = nome.toLowerCase().replace(/\s+/g, '-');
    return cana.transaction('readwrite', ['categorias', 'tarefas'], async (scope) => {
      await scope.table<Categoria>('categorias').put({
        id: categoriaId,
        nome,
        cor: '#7c3aed',
        criadaEm: agora,
        atualizadaEm: agora
      });
      await scope.table<Tarefa>('tarefas').put({
        id: crypto.randomUUID(),
        titulo,
        categoriaId,
        concluida: false,
        prioridade: 'alta',
        criadaEm: agora,
        atualizadaEm: agora
      });
    });
  }
);

export async function adicionarTarefa(titulo: string, categoriaId: string) {
  const agora = Date.now();
  await cana.table<Tarefa>('tarefas').add({
    id: crypto.randomUUID(),
    titulo,
    categoriaId,
    concluida: false,
    prioridade: 'media',
    criadaEm: agora,
    atualizadaEm: agora
  });
}

export async function alternarTarefa(tarefa: Tarefa) {
  await cana.table<Tarefa>('tarefas').update(tarefa.id, {
    concluida: !tarefa.concluida,
    atualizadaEm: Date.now()
  });
}