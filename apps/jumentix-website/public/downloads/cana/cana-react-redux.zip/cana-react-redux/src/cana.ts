import { createClient, type CanaChangeEvent, type CanaSchema } from '@jumentix/cana';

export type Categoria = {
  id: string;
  nome: string;
  cor: string;
  criadaEm: number;
  atualizadaEm: number;
};

export type Tarefa = {
  id: string;
  titulo: string;
  categoriaId: string;
  concluida: boolean;
  prioridade: 'baixa' | 'media' | 'alta';
  notas?: string;
  criadaEm: number;
  atualizadaEm: number;
};

export const esquemaTarefas: CanaSchema = {
  version: 1,
  stores: [
    { name: 'categorias', keyPath: 'id', indexes: [{ name: 'porNome', keyPath: 'nome', unique: true }] },
    {
      name: 'tarefas',
      keyPath: 'id',
      indexes: [
        { name: 'porCategoria', keyPath: 'categoriaId' },
        { name: 'porConcluida', keyPath: 'concluida' },
        { name: 'porAtualizadaEm', keyPath: 'atualizadaEm' }
      ]
    }
  ]
};

export const cana = createClient({
  name: 'tutorial-cana-tarefas',
  schema: esquemaTarefas,
  originId: 'tarefas-ui',
  retainedEvents: 100
});

export async function abrirBancoDeTarefas() {
  await cana.open();
  return cana;
}

export async function carregarTudo() {
  const [categorias, tarefas] = await Promise.all([
    cana.table<Categoria>('categorias').query({ index: 'porNome' }),
    cana.table<Tarefa>('tarefas').query({ index: 'porAtualizadaEm' })
  ]);
  return { categorias: [...categorias], tarefas: [...tarefas] };
}

export async function criarDadosIniciais() {
  await abrirBancoDeTarefas();
  if (await cana.table<Categoria>('categorias').count()) return;
  const agora = Date.now();
  await cana.transaction('readwrite', ['categorias', 'tarefas'], async (scope) => {
    await scope.table<Categoria>('categorias').bulkAdd([
      { id: 'trabalho', nome: 'Trabalho', cor: '#2563eb', criadaEm: agora, atualizadaEm: agora },
      { id: 'casa', nome: 'Casa', cor: '#16a34a', criadaEm: agora, atualizadaEm: agora }
    ]);
    await scope.table<Tarefa>('tarefas').bulkAdd([
      {
        id: 'tarefa-1',
        titulo: 'Escrever tutorial do Cana',
        categoriaId: 'trabalho',
        concluida: false,
        prioridade: 'alta',
        criadaEm: agora,
        atualizadaEm: agora
      },
      {
        id: 'tarefa-2',
        titulo: 'Revisar filtros por categoria',
        categoriaId: 'casa',
        concluida: true,
        prioridade: 'media',
        criadaEm: agora,
        atualizadaEm: agora
      }
    ]);
  });
}

export function textoEvento(event: CanaChangeEvent) {
  return event.cursor + ': ' + event.type + ' ' + event.store + '/' + String(event.key ?? 'all');
}