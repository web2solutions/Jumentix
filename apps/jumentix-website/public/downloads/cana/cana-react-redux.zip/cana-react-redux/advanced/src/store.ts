import { configureStore, createAsyncThunk, createSlice, type PayloadAction } from '@reduxjs/toolkit';
import { isCanaErrorCode, type CanaChangeEvent } from '@jumentix/cana';
import { connectCanaToRedux } from '@jumentix/cana-react/redux';
import { cana, loadAll, seedInitialData, formatEvent, type Category, type Task } from './cana';

type State = { categories: Category[]; tasks: Task[]; events: string[]; canaError: unknown };
let lastCursor = Number(localStorage.getItem('redux:lastCursor') ?? 0);

function upsert<T extends { id: string }>(records: T[], record: T) {
  return records.filter((item) => item.id !== record.id).concat(record);
}

const slice = createSlice({
  name: 'tasks',
  initialState: { categories: [], tasks: [], events: [], canaError: null } as State,
  reducers: {
    replaceAll(state, action: PayloadAction<{ categories: Category[]; tasks: Task[] }>) {
      state.categories = action.payload.categories;
      state.tasks = action.payload.tasks;
    },
    setCanaError(state, action: PayloadAction<unknown>) {
      state.canaError = action.payload;
    },
    applyCanaEvent(state, action: PayloadAction<CanaChangeEvent>) {
      const event = action.payload;
      lastCursor = event.cursor;
      localStorage.setItem('redux:lastCursor', String(lastCursor));
      state.events = [...state.events, formatEvent(event)].slice(-8);
      if (event.store === 'categories' && event.record) {
        state.categories = upsert(state.categories, event.record as Category)
          .sort((a, b) => a.name.localeCompare(b.name));
      }
      if (event.store === 'tasks' && event.record) {
        state.tasks = upsert(state.tasks, event.record as Task)
          .sort((a, b) => a.updatedAt - b.updatedAt);
      }
    }
  }
});

export const { applyCanaEvent, replaceAll, setCanaError } = slice.actions;
export const store = configureStore({ reducer: slice.reducer });
export type RootState = ReturnType<typeof store.getState>;

export async function startCanaReduxWithReplay() {
  await seedInitialData();
  store.dispatch(replaceAll(await loadAll()));
  try {
    const bridge = connectCanaToRedux({
      client: cana,
      dispatch: store.dispatch,
      sinceCursor: lastCursor,
      mapEvent: (event) => applyCanaEvent(event)
    });
    return bridge.stop;
  } catch (error) {
    if (isCanaErrorCode(error, 'NotFound')) {
      store.dispatch(replaceAll(await loadAll()));
      const bridge = connectCanaToRedux({
        client: cana,
        dispatch: store.dispatch,
        mapEvent: (event) => applyCanaEvent(event)
      });
      return bridge.stop;
    }
    store.dispatch(setCanaError(error));
    throw error;
  }
}

export const createCategoryWithFirstTask = createAsyncThunk(
  'tasks/createCategoryWithFirstTask',
  async ({ name, title }: { name: string; title: string }) => {
    const now = Date.now();
    const categoryId = name.toLowerCase().replace(/\s+/g, '-');
    return cana.transaction('readwrite', ['categories', 'tasks'], async (scope) => {
      await scope.table<Category>('categories').put({
        id: categoryId,
        name,
        color: '#7c3aed',
        createdAt: now,
        updatedAt: now
      });
      await scope.table<Task>('tasks').put({
        id: crypto.randomUUID(),
        title,
        categoryId,
        completed: false,
        priority: 'high',
        createdAt: now,
        updatedAt: now
      });
    });
  }
);

export async function addTask(title: string, categoryId: string) {
  const now = Date.now();
  await cana.table<Task>('tasks').add({
    id: crypto.randomUUID(),
    title,
    categoryId,
    completed: false,
    priority: 'medium',
    createdAt: now,
    updatedAt: now
  });
}

export async function toggleTask(task: Task) {
  await cana.table<Task>('tasks').update(task.id, {
    completed: !task.completed,
    updatedAt: Date.now()
  });
}