import { useEffect } from 'react';
import { Provider, useDispatch, useSelector } from 'react-redux';
import {
  addTask,
  toggleTask,
  createCategoryWithFirstTask,
  startCanaReduxWithReplay,
  store,
  type RootState
} from './store';

function AdvancedReduxBoard() {
  const dispatch = useDispatch<typeof store.dispatch>();
  const { categories, tasks, events } = useSelector((state: RootState) => state);

  useEffect(() => {
    let stop = () => {};
    void startCanaReduxWithReplay().then((cleanup) => { stop = cleanup; });
    return () => stop();
  }, []);

  return (
    <main className="app">
      <h1>Cana + React Redux advanced</h1>
      <div className="toolbar">
        <button onClick={() => void addTask('New Redux task', 'work')}>Add task</button>
        <button onClick={() => void dispatch(createCategoryWithFirstTask({
          name: 'Release',
          title: 'Created in one transaction'
        }))}>
          Create category + task
        </button>
      </div>
      <section className="board">
        {categories.map((category) => (
          <article className="category" key={category.id}>
            <h2>{category.name}</h2>
            {tasks.filter((task) => task.categoryId === category.id).map((task) => (
              <button className="task" key={task.id} onClick={() => void toggleTask(task)}>
                {task.completed ? 'Done: ' : ''}{task.title}
              </button>
            ))}
          </article>
        ))}
      </section>
      <pre className="events">{events.join('\n') || 'No events yet.'}</pre>
    </main>
  );
}

export default function App() {
  return (
    <Provider store={store}>
      <AdvancedReduxBoard />
    </Provider>
  );
}