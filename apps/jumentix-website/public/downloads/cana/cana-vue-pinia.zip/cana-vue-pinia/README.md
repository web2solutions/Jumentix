# cana-vue-pinia

This archive contains both runnable variants used by the Cana documentation:

- `simple/`
- `advanced/`

Run either app:

```bash
cd simple
npm install
npm run dev
```

Build either app:

```bash
cd advanced
npm install
npm run build
```
