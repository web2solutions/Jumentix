# cana-vue-pinia

Run the example app:

```bash
npm install
npm run dev
```

Build the example app:

```bash
npm run build
```
