import { defineStore } from 'pinia';
import { isCanaErrorCode } from '@jumentix/cana';
import { applyCanaEventToRecords, connectCanaToPinia } from '@jumentix/cana-vue';
import { cana, loadAll, seedInitialData, formatEvent, type Category, type Task } from '../cana';

let lastCursor = Number(localStorage.getItem('pinia:lastCursor') ?? 0);

export const useTasksStore = defineStore('advancedTasks', {
  state: () => ({
    categories: [] as Category[],
    tasks: [] as Task[],
    events: [] as string[],
    canaError: null as unknown
  }),
  getters: {
    byCategory: (state) => (categoryId: string) =>
      state.tasks.filter((task) => task.categoryId === categoryId)
  },
  actions: {
    async init() {
      await seedInitialData();
      Object.assign(this, await loadAll());
      try {
        const bridge = connectCanaToPinia({
          client: cana,
          sinceCursor: lastCursor,
          apply: (event) => this.applyEvent(event)
        });
        return bridge.stop;
      } catch (error) {
        if (isCanaErrorCode(error, 'NotFound')) {
          Object.assign(this, await loadAll());
          const bridge = connectCanaToPinia({
            client: cana,
            apply: (event) => this.applyEvent(event)
          });
          return bridge.stop;
        }
        this.canaError = error;
        throw error;
      }
    },
    applyEvent(event: Parameters<typeof formatEvent>[0]) {
      lastCursor = event.cursor;
      localStorage.setItem('pinia:lastCursor', String(lastCursor));
      this.events = [...this.events, formatEvent(event)].slice(-8);
      this.categories = applyCanaEventToRecords(this.categories, event, {
        store: 'categories',
        getKey: (category) => category.id,
        sort: (a, b) => a.name.localeCompare(b.name)
      });
      this.tasks = applyCanaEventToRecords(this.tasks, event, {
        store: 'tasks',
        getKey: (task) => task.id,
        sort: (a, b) => a.updatedAt - b.updatedAt
      });
    },
    async createCategoryWithFirstTask(name: string, title: string) {
      const now = Date.now();
      const categoryId = name.toLowerCase().replace(/\s+/g, '-');
      await cana.transaction('readwrite', ['categories', 'tasks'], async (scope) => {
        await scope.table<Category>('categories').put({
          id: categoryId,
          name,
          color: '#dc2626',
          createdAt: now,
          updatedAt: now
        });
        await scope.table<Task>('tasks').put({
          id: crypto.randomUUID(),
          title,
          categoryId,
          completed: false,
          priority: 'high',
          createdAt: now,
          updatedAt: now
        });
      });
    },
    async toggleTask(task: Task) {
      await cana.table<Task>('tasks').update(task.id, {
        completed: !task.completed,
        updatedAt: Date.now()
      });
    }
  }
});