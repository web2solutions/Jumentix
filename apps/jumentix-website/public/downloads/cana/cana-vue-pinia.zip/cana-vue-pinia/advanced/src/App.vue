<script setup lang="ts">
import { onMounted, onUnmounted } from 'vue';
import { useTasksStore } from './stores/advancedTasks';

const tasks = useTasksStore();
let stop = () => {};

onMounted(async () => {
  stop = await tasks.init();
});
onUnmounted(() => stop());
</script>

<template>
  <main class="app">
    <h1>Cana + Vue 3 + Pinia advanced</h1>
    <div class="toolbar">
      <button @click="tasks.createCategoryWithFirstTask('QA', 'Created in one transaction')">
        Create category + task
      </button>
    </div>
    <section class="board">
      <article v-for="category in tasks.categories" :key="category.id" class="category">
        <h2>{{ category.name }}</h2>
        <button
          v-for="task in tasks.byCategory(category.id)"
          :key="task.id"
          class="task"
          @click="tasks.toggleTask(task)"
        >
          {{ task.completed ? 'Done: ' : '' }}{{ task.title }}
        </button>
      </article>
    </section>
    <pre class="events">{{ tasks.events.join('\n') || 'No events yet.' }}</pre>
  </main>
</template>