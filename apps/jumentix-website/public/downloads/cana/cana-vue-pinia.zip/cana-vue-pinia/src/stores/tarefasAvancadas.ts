import { defineStore } from 'pinia';
import { isCanaErrorCode } from '@jumentix/cana';
import { applyCanaEventToRecords, connectCanaToPinia } from '@jumentix/cana-vue';
import { cana, carregarTudo, criarDadosIniciais, textoEvento, type Categoria, type Tarefa } from '../cana';

let ultimoCursor = Number(localStorage.getItem('pinia:lastCursor') ?? 0);

export const useTarefasStore = defineStore('tarefasAvancadas', {
  state: () => ({
    categorias: [] as Categoria[],
    tarefas: [] as Tarefa[],
    eventos: [] as string[],
    canaError: null as unknown
  }),
  getters: {
    porCategoria: (state) => (categoriaId: string) =>
      state.tarefas.filter((tarefa) => tarefa.categoriaId === categoriaId)
  },
  actions: {
    async init() {
      await criarDadosIniciais();
      Object.assign(this, await carregarTudo());
      try {
        const bridge = connectCanaToPinia({
          client: cana,
          sinceCursor: ultimoCursor,
          apply: (event) => this.applyEvent(event)
        });
        return bridge.stop;
      } catch (error) {
        if (isCanaErrorCode(error, 'NotFound')) {
          Object.assign(this, await carregarTudo());
          const bridge = connectCanaToPinia({
            client: cana,
            apply: (event) => this.applyEvent(event)
          });
          return bridge.stop;
        }
        this.canaError = error;
        throw error;
      }
    },
    applyEvent(event: Parameters<typeof textoEvento>[0]) {
      ultimoCursor = event.cursor;
      localStorage.setItem('pinia:lastCursor', String(ultimoCursor));
      this.eventos = [...this.eventos, textoEvento(event)].slice(-8);
      this.categorias = applyCanaEventToRecords(this.categorias, event, {
        store: 'categorias',
        getKey: (categoria) => categoria.id,
        sort: (a, b) => a.nome.localeCompare(b.nome)
      });
      this.tarefas = applyCanaEventToRecords(this.tarefas, event, {
        store: 'tarefas',
        getKey: (tarefa) => tarefa.id,
        sort: (a, b) => a.atualizadaEm - b.atualizadaEm
      });
    },
    async criarCategoriaComPrimeiraTarefa(nome: string, titulo: string) {
      const agora = Date.now();
      const categoriaId = nome.toLowerCase().replace(/\s+/g, '-');
      await cana.transaction('readwrite', ['categorias', 'tarefas'], async (scope) => {
        await scope.table<Categoria>('categorias').put({
          id: categoriaId,
          nome,
          cor: '#dc2626',
          criadaEm: agora,
          atualizadaEm: agora
        });
        await scope.table<Tarefa>('tarefas').put({
          id: crypto.randomUUID(),
          titulo,
          categoriaId,
          concluida: false,
          prioridade: 'alta',
          criadaEm: agora,
          atualizadaEm: agora
        });
      });
    },
    async alternarTarefa(tarefa: Tarefa) {
      await cana.table<Tarefa>('tarefas').update(tarefa.id, {
        concluida: !tarefa.concluida,
        atualizadaEm: Date.now()
      });
    }
  }
});