<script setup lang="ts">
import { onMounted, onUnmounted } from 'vue';
import { useTarefasStore } from './stores/tarefasAvancadas';

const tarefas = useTarefasStore();
let stop = () => {};

onMounted(async () => {
  stop = await tarefas.init();
});
onUnmounted(() => stop());
</script>

<template>
  <main class="app">
    <h1>Cana + Vue 3 + Pinia avancado</h1>
    <div class="toolbar">
      <button @click="tarefas.criarCategoriaComPrimeiraTarefa('QA', 'Criada em uma transacao')">
        Criar categoria + tarefa
      </button>
    </div>
    <section class="board">
      <article v-for="categoria in tarefas.categorias" :key="categoria.id" class="categoria">
        <h2>{{ categoria.nome }}</h2>
        <button
          v-for="tarefa in tarefas.porCategoria(categoria.id)"
          :key="tarefa.id"
          class="tarefa"
          @click="tarefas.alternarTarefa(tarefa)"
        >
          {{ tarefa.concluida ? 'Concluida: ' : '' }}{{ tarefa.titulo }}
        </button>
      </article>
    </section>
    <pre class="eventos">{{ tarefas.eventos.join('\n') || 'Sem eventos ainda.' }}</pre>
  </main>
</template>