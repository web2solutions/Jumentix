import { defineStore } from 'pinia';
import { applyCanaEventToRecords, connectCanaToPinia } from '@jumentix/cana-vue';
import { cana, loadAll, seedInitialData, formatEvent, type Category, type Task } from '../cana';

export const useTasksStore = defineStore('tasks', {
  state: () => ({
    categories: [] as Category[],
    tasks: [] as Task[],
    events: [] as string[]
  }),
  getters: {
    byCategory: (state) => (categoryId: string) =>
      state.tasks.filter((task) => task.categoryId === categoryId)
  },
  actions: {
    async init() {
      await seedInitialData();
      Object.assign(this, await loadAll());
      const bridge = connectCanaToPinia({
        client: cana,
        apply: (event) => this.applyEvent(event)
      });
      return bridge.stop;
    },
    applyEvent(event: Parameters<typeof formatEvent>[0]) {
      this.events = [...this.events, formatEvent(event)].slice(-8);
      this.categories = applyCanaEventToRecords(this.categories, event, {
        store: 'categories',
        getKey: (category) => category.id,
        sort: (a, b) => a.name.localeCompare(b.name)
      });
      this.tasks = applyCanaEventToRecords(this.tasks, event, {
        store: 'tasks',
        getKey: (task) => task.id,
        sort: (a, b) => a.updatedAt - b.updatedAt
      });
    },
    async addTask(title: string, categoryId: string) {
      const now = Date.now();
      await cana.table<Task>('tasks').add({
        id: crypto.randomUUID(),
        title,
        categoryId,
        completed: false,
        priority: 'medium',
        createdAt: now,
        updatedAt: now
      });
    },
    async toggleTask(task: Task) {
      await cana.table<Task>('tasks').update(task.id, {
        completed: !task.completed,
        updatedAt: Date.now()
      });
    }
  }
});