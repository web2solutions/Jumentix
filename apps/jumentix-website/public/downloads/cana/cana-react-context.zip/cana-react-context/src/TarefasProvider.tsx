import React, { createContext, useContext, useEffect, useReducer, useState } from 'react';
import { applyCanaEventToRecords, useCanaSubscription } from '@jumentix/cana-react';
import { cana, carregarTudo, criarDadosIniciais, textoEvento, type Categoria, type Tarefa } from './cana';

type State = { categorias: Categoria[]; tarefas: Tarefa[]; eventos: string[] };
type Action =
  | { type: 'loaded'; payload: Omit<State, 'eventos'> }
  | { type: 'event'; event: Parameters<typeof textoEvento>[0] };

function reducer(state: State, action: Action): State {
  if (action.type === 'loaded') return { ...action.payload, eventos: [] };
  const event = action.event;
  return {
    categorias: applyCanaEventToRecords(state.categorias, event, {
      store: 'categorias',
      getKey: (categoria) => categoria.id,
      sort: (a, b) => a.nome.localeCompare(b.nome)
    }),
    tarefas: applyCanaEventToRecords(state.tarefas, event, {
      store: 'tarefas',
      getKey: (tarefa) => tarefa.id,
      sort: (a, b) => a.atualizadaEm - b.atualizadaEm
    }),
    eventos: [...state.eventos, textoEvento(event)].slice(-8)
  };
}

const TarefasContext = createContext<{
  state: State;
  adicionarTarefa(titulo: string, categoriaId: string): Promise<void>;
  alternarTarefa(tarefa: Tarefa): Promise<void>;
} | null>(null);

export function TarefasProvider({ children }: { children: React.ReactNode }) {
  const [ready, setReady] = useState(false);
  const [state, dispatch] = useReducer(reducer, { categorias: [], tarefas: [], eventos: [] });

  useEffect(() => {
    let alive = true;
    void criarDadosIniciais()
      .then(carregarTudo)
      .then((payload) => {
        if (!alive) return;
        dispatch({ type: 'loaded', payload });
        setReady(true);
      });
    return () => { alive = false; };
  }, []);

  useCanaSubscription(ready ? cana : null, (event) => {
    dispatch({ type: 'event', event });
  });

  const api = {
    state,
    async adicionarTarefa(titulo: string, categoriaId: string) {
      const agora = Date.now();
      await cana.table<Tarefa>('tarefas').add({
        id: crypto.randomUUID(),
        titulo,
        categoriaId,
        concluida: false,
        prioridade: 'media',
        criadaEm: agora,
        atualizadaEm: agora
      });
    },
    async alternarTarefa(tarefa: Tarefa) {
      await cana.table<Tarefa>('tarefas').update(tarefa.id, {
        concluida: !tarefa.concluida,
        atualizadaEm: Date.now()
      });
    }
  };

  return <TarefasContext.Provider value={api}>{children}</TarefasContext.Provider>;
}

export function useTarefas() {
  const ctx = useContext(TarefasContext);
  if (!ctx) throw new Error('useTarefas must run inside TarefasProvider');
  return ctx;
}