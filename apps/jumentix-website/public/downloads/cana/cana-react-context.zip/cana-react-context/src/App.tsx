import { criarCategoriaComPrimeiraTarefa } from './advancedCana';
import { TarefasProvider, useTarefas } from './TarefasProvider';

function QuadroAvancado() {
  const { state, adicionarTarefa, alternarTarefa } = useTarefas();
  const grupos = state.categorias.map((categoria) => ({
    categoria,
    tarefas: state.tarefas.filter((tarefa) => tarefa.categoriaId === categoria.id)
  }));

  return (
    <main className="app">
      <h1>Cana + React Context avancado</h1>
      <div className="toolbar">
        <button onClick={() => void adicionarTarefa('Tarefa avulsa', 'trabalho')}>Adicionar tarefa</button>
        <button onClick={() => void criarCategoriaComPrimeiraTarefa('Operacoes', 'Criada na mesma transacao')}>
          Criar categoria + tarefa
        </button>
      </div>
      <section className="board">
        {grupos.map(({ categoria, tarefas }) => (
          <article className="categoria" key={categoria.id}>
            <h2>{categoria.nome}</h2>
            {tarefas.map((tarefa) => (
              <button className="tarefa" key={tarefa.id} onClick={() => void alternarTarefa(tarefa)}>
                {tarefa.concluida ? 'Concluida: ' : ''}{tarefa.titulo}
              </button>
            ))}
          </article>
        ))}
      </section>
      <pre className="eventos">{state.eventos.join('\n') || 'Sem eventos ainda.'}</pre>
    </main>
  );
}

export default function App() {
  return (
    <TarefasProvider>
      <QuadroAvancado />
    </TarefasProvider>
  );
}