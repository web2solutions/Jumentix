import { isCanaErrorCode, type CanaChangeEvent } from '@jumentix/cana';
import { cana, carregarTudo, type Categoria, type Tarefa } from './cana';

let ultimoCursor = Number(localStorage.getItem('tarefas:lastCursor') ?? 0);

export async function ouvirComReplay(apply: (event: CanaChangeEvent) => void) {
  try {
    return cana.subscribe((event) => {
      apply(event);
      ultimoCursor = event.cursor;
      localStorage.setItem('tarefas:lastCursor', String(ultimoCursor));
    }, { sinceCursor: ultimoCursor });
  } catch (error) {
    if (isCanaErrorCode(error, 'NotFound')) {
      await carregarTudo();
      return cana.subscribe(apply);
    }
    throw error;
  }
}

export async function criarCategoriaComPrimeiraTarefa(nome: string, titulo: string) {
  const agora = Date.now();
  const categoriaId = nome.toLowerCase().replace(/\s+/g, '-');
  return cana.transaction('readwrite', ['categorias', 'tarefas'], async (scope) => {
    await scope.table<Categoria>('categorias').put({
      id: categoriaId,
      nome,
      cor: '#f97316',
      criadaEm: agora,
      atualizadaEm: agora
    });
    await scope.table<Tarefa>('tarefas').put({
      id: crypto.randomUUID(),
      titulo,
      categoriaId,
      concluida: false,
      prioridade: 'alta',
      criadaEm: agora,
      atualizadaEm: agora
    });
  });
}