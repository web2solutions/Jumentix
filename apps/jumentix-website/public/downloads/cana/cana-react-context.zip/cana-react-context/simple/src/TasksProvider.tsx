import React, { createContext, useContext, useEffect, useReducer, useState } from 'react';
import { applyCanaEventToRecords, useCanaSubscription } from '@jumentix/cana-react';
import { cana, loadAll, seedInitialData, formatEvent, type Category, type Task } from './cana';

type State = { categories: Category[]; tasks: Task[]; events: string[] };
type Action =
  | { type: 'loaded'; payload: Omit<State, 'events'> }
  | { type: 'event'; event: Parameters<typeof formatEvent>[0] };

function reducer(state: State, action: Action): State {
  if (action.type === 'loaded') return { ...action.payload, events: [] };
  const event = action.event;
  return {
    categories: applyCanaEventToRecords(state.categories, event, {
      store: 'categories',
      getKey: (category) => category.id,
      sort: (a, b) => a.name.localeCompare(b.name)
    }),
    tasks: applyCanaEventToRecords(state.tasks, event, {
      store: 'tasks',
      getKey: (task) => task.id,
      sort: (a, b) => a.updatedAt - b.updatedAt
    }),
    events: [...state.events, formatEvent(event)].slice(-8)
  };
}

const TasksContext = createContext<{
  state: State;
  addTask(title: string, categoryId: string): Promise<void>;
  toggleTask(task: Task): Promise<void>;
} | null>(null);

export function TasksProvider({ children }: { children: React.ReactNode }) {
  const [ready, setReady] = useState(false);
  const [state, dispatch] = useReducer(reducer, { categories: [], tasks: [], events: [] });

  useEffect(() => {
    let alive = true;
    void seedInitialData()
      .then(loadAll)
      .then((payload) => {
        if (!alive) return;
        dispatch({ type: 'loaded', payload });
        setReady(true);
      });
    return () => { alive = false; };
  }, []);

  useCanaSubscription(ready ? cana : null, (event) => {
    dispatch({ type: 'event', event });
  });

  const api = {
    state,
    async addTask(title: string, categoryId: string) {
      const now = Date.now();
      await cana.table<Task>('tasks').add({
        id: crypto.randomUUID(),
        title,
        categoryId,
        completed: false,
        priority: 'medium',
        createdAt: now,
        updatedAt: now
      });
    },
    async toggleTask(task: Task) {
      await cana.table<Task>('tasks').update(task.id, {
        completed: !task.completed,
        updatedAt: Date.now()
      });
    }
  };

  return <TasksContext.Provider value={api}>{children}</TasksContext.Provider>;
}

export function useTasks() {
  const ctx = useContext(TasksContext);
  if (!ctx) throw new Error('useTasks must run inside TasksProvider');
  return ctx;
}