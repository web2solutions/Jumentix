import { isCanaErrorCode, type CanaChangeEvent } from '@jumentix/cana';
import { cana, loadAll, type Category, type Task } from './cana';

let lastCursor = Number(localStorage.getItem('tasks:lastCursor') ?? 0);

export async function subscribeWithReplay(
  apply: (event: CanaChangeEvent) => void,
  reload: () => Promise<void>
) {
  const rememberAndApply = (event: CanaChangeEvent) => {
    apply(event);
    lastCursor = event.cursor;
    localStorage.setItem('tasks:lastCursor', String(lastCursor));
  };
  try {
    return cana.subscribe(rememberAndApply, { sinceCursor: lastCursor });
  } catch (error) {
    if (isCanaErrorCode(error, 'NotFound')) {
      lastCursor = 0;
      localStorage.setItem('tasks:lastCursor', '0');
      await reload();
      return cana.subscribe(rememberAndApply);
    }
    throw error;
  }
}

export async function createCategoryWithFirstTask(name: string, title: string) {
  const now = Date.now();
  const categoryId = name.toLowerCase().replace(/\s+/g, '-');
  return cana.transaction('readwrite', ['categories', 'tasks'], async (scope) => {
    await scope.table<Category>('categories').put({
      id: categoryId,
      name,
      color: '#f97316',
      createdAt: now,
      updatedAt: now
    });
    await scope.table<Task>('tasks').put({
      id: crypto.randomUUID(),
      title,
      categoryId,
      completed: false,
      priority: 'high',
      createdAt: now,
      updatedAt: now
    });
  });
}