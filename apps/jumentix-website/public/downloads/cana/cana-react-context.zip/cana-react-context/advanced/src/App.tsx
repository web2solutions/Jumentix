import { createCategoryWithFirstTask } from './advancedCana';
import { TasksProvider, useTasks } from './TasksProvider';

function AdvancedTaskBoard() {
  const { state, addTask, toggleTask } = useTasks();
  const groups = state.categories.map((category) => ({
    category,
    tasks: state.tasks.filter((task) => task.categoryId === category.id)
  }));

  return (
    <main className="app">
      <h1>Cana + React Context advanced</h1>
      <div className="toolbar">
        <button onClick={() => void addTask('Standalone task', 'work')}>Add task</button>
        <button onClick={() => void createCategoryWithFirstTask('Operations', 'Created in the same transaction')}>
          Create category + task
        </button>
      </div>
      <section className="board">
        {groups.map(({ category, tasks }) => (
          <article className="category" key={category.id}>
            <h2>{category.name}</h2>
            {tasks.map((task) => (
              <button className="task" key={task.id} onClick={() => void toggleTask(task)}>
                {task.completed ? 'Done: ' : ''}{task.title}
              </button>
            ))}
          </article>
        ))}
      </section>
      <pre className="events">{state.events.join('\n') || 'No events yet.'}</pre>
    </main>
  );
}

export default function App() {
  return (
    <TasksProvider>
      <AdvancedTaskBoard />
    </TasksProvider>
  );
}