# cana-react-context advanced

This downloadable archive vendors local @jumentix packages so the app can install and build before those packages are published to npm.

Run the example app:

```bash
npm install
npm run dev
```

Build the example app:

```bash
npm run build
```
